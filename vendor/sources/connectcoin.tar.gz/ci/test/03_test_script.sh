#!/usr/bin/env bash
#
# Copyright (c) 2018-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

set -o errexit -o xtrace -o pipefail

# Also invalidate direct/container invocations before any early failure.
if [ -n "${BASE_BUILD_DIR:-}" ]; then
  rm -f -- "${BASE_BUILD_DIR}/.ci-depends-complete" \
    "${BASE_BUILD_DIR}/.ci-build-complete" "${BASE_BUILD_DIR}/.ci-build-complete.tmp"
fi

if [ "${DANGER_RUN_CI_ON_HOST}" != "1" ]; then
  echo "This script will make unsafe local and global modifications, so it can only be run inside a container and requires DANGER_RUN_CI_ON_HOST=1"
  exit 1
fi

cd "${BASE_ROOT_DIR}"

export PATH="/path_with space:${PATH}"
export ASAN_OPTIONS="detect_leaks=1:detect_stack_use_after_return=1:check_initialization_order=1:strict_init_order=1"
export LSAN_OPTIONS="suppressions=${BASE_ROOT_DIR}/test/sanitizer_suppressions/lsan:print_suppressions=0"
export TSAN_OPTIONS="suppressions=${BASE_ROOT_DIR}/test/sanitizer_suppressions/tsan:halt_on_error=1:second_deadlock_stack=1"
export UBSAN_OPTIONS="suppressions=${BASE_ROOT_DIR}/test/sanitizer_suppressions/ubsan:print_stacktrace=1:halt_on_error=1:report_error_type=1"

echo "Number of available processing units: $(nproc)"
if [ "$CI_OS_NAME" == "macos" ]; then
  top -l 1 -s 0 | awk ' /PhysMem/ {print}'
else
  free -m -h
  echo "System info: $(uname --kernel-name --kernel-release)"
  lscpu
fi
echo "Free disk space:"
df -h

# We force an install of linux-headers again here via $PACKAGES to fix any
# kernel mismatch between a cached docker image and the underlying host.
# This can happen occasionally on hosted runners if the runner image is updated.
if [[ "$CONTAINER_NAME" == "ci_native_asan" ]]; then
  $CI_RETRY_EXE apt-get -o APT::Update::Error-Mode=any update
  ${CI_RETRY_EXE} bash -c "apt-get install --no-install-recommends --no-upgrade -y $PACKAGES"
fi

# What host to compile for. See also ./depends/README.md
# Tests that need cross-compilation export the appropriate HOST.
# Tests that run natively guess the host
export HOST=${HOST:-$("$BASE_ROOT_DIR/depends/config.guess")}

echo "=== BEGIN env ==="
env
echo "=== END env ==="

# The CI framework should be flexible where it is run from. For example, from
# a git-archive, a git-worktree, or a normal git repo.
# The iwyu task requires a working git repo, which may not always be
# available, so initialize one with force.
if [[ "${RUN_IWYU}" == true ]]; then
  mv .git .git_ci_backup || true
  git init
  git add ./src  # the git diff command used later for iwyu only cares about ./src
  git config user.email "ci@ci"
  git config user.name "CI"
  git commit -m "dummy CI ./src init for IWYU"
fi

if [ "$RUN_FUZZ_TESTS" = "true" ]; then
  export DIR_FUZZ_IN=${DIR_QA_ASSETS}/fuzz_corpora/
  python3 "${BASE_ROOT_DIR}/ci/test/qa_assets.py" "${DIR_QA_ASSETS}"
fi

# Make sure default datadir does not exist and is never read by creating a dummy file
if [ "$CI_OS_NAME" == "macos" ]; then
  echo > "${HOME}/Library/Application Support/ConnectCoin"
else
  echo > "${HOME}/.connectcoin"
fi

if [ -z "$NO_DEPENDS" ]; then
  if [[ $CI_IMAGE_NAME_TAG == *alpine* ]]; then
    SHELL_OPTS="CONFIG_SHELL=/usr/bin/dash"
  else
    SHELL_OPTS="CONFIG_SHELL="
  fi
  bash -c "$SHELL_OPTS make $MAKEJOBS -C depends HOST=$HOST $DEP_OPTS LOG=1"
  # Only a successful complete dependency build may publish immutable caches.
  # BASE_BUILD_DIR is host-bound in cache-enabled jobs, never a restored cache.
  if [ -n "${BASE_BUILD_DIR:-}" ] && [ -n "${CI_DEPENDS_CACHE_RUN:-}" ]; then
    mkdir -p -- "${BASE_BUILD_DIR}"
    printf '%s\n' "${CI_DEPENDS_CACHE_RUN}" > "${BASE_BUILD_DIR}/.ci-depends-complete"
  fi
fi
CONNECTCOIN_CONFIG_ALL="-DCMAKE_COMPILE_WARNING_AS_ERROR=ON -DBUILD_BENCH=ON -DBUILD_FUZZ_BINARY=ON"
if [ -z "$NO_DEPENDS" ]; then
  CONNECTCOIN_CONFIG_ALL="${CONNECTCOIN_CONFIG_ALL} -DCMAKE_TOOLCHAIN_FILE=$DEPENDS_DIR/$HOST/toolchain.cmake"
fi

# A small export budget can evict restored entries before their compilation
# units are reached. Use a bounded working budget, then trim every bucket.
# GHA's cleanup budget reserves export space for metadata not counted by ccache.
# The EXIT fallback also covers a configure/build failure; cache maintenance
# must not replace that failure's status or turn a successful build into a failure.
CI_CCACHE_EXPORT_MAXSIZE="${CCACHE_MAXSIZE}"
ci_cleanup_ccache() {
  export CCACHE_MAXSIZE="${CI_CCACHE_CLEANUP_MAXSIZE:-$CI_CCACHE_EXPORT_MAXSIZE}"
  if ! ccache --cleanup; then
    echo "Warning: ccache cleanup failed; preserving the CI result" >&2
  fi
  export CCACHE_MAXSIZE="${CI_CCACHE_EXPORT_MAXSIZE}"
}
trap ci_cleanup_ccache EXIT
export CCACHE_MAXSIZE="${CI_CCACHE_BUILD_MAXSIZE:-$CCACHE_MAXSIZE}"
ccache --zero-stats

# Folder where the build is done.
BASE_BUILD_DIR=${BASE_BUILD_DIR:-$BASE_SCRATCH_DIR/build-$HOST}

CONNECTCOIN_CONFIG_ALL="$CONNECTCOIN_CONFIG_ALL '-DCMAKE_INSTALL_PREFIX=$BASE_OUTDIR' -Werror=dev"

if [[ "${RUN_IWYU}" == true || "${RUN_TIDY}" == true ]]; then
  CONNECTCOIN_CONFIG_ALL="$CONNECTCOIN_CONFIG_ALL -DCMAKE_EXPORT_COMPILE_COMMANDS=ON"
fi

eval "CMAKE_ARGS=($CONNECTCOIN_CONFIG_ALL $CONNECTCOIN_CONFIG)"
cmake -S "$BASE_ROOT_DIR" -B "$BASE_BUILD_DIR" "${CMAKE_ARGS[@]}" || (
  cd "${BASE_BUILD_DIR}"
  # shellcheck disable=SC2046
  cat $(cmake -P "${BASE_ROOT_DIR}/ci/test/GetCMakeLogFiles.cmake")
  false
)

# Preserve GOAL for the deployment checks after the build.
BUILD_GOALS="${GOAL}"
if [[ "${GOAL}" != all && "${GOAL}" != codegen ]]; then
  BUILD_GOALS="all ${GOAL}"
fi

# Keep compiler commands in the original log. A serial diagnostic rebuild can
# spend many minutes building unrelated targets before reaching the same error.
# shellcheck disable=SC2086
cmake --build "${BASE_BUILD_DIR}" "$MAKEJOBS" --target $BUILD_GOALS --verbose

if [[ "${RUN_IWYU}" == true ]]; then
  # CMake's codegen target does not include the custom Cap'n Proto/mpgen
  # commands. Generate their outputs explicitly so IWYU can inspect every
  # compile command without failing on headers and sources that do not exist.
  cmake --build "${BASE_BUILD_DIR}" "$MAKEJOBS" --target \
    mp_headers \
    mptest_headers \
    connectcoin_ipc_headers \
    connectcoin_ipc_test_headers \
    connectcoin_ipc_fuzz_headers
fi

ci_cleanup_ccache
trap - EXIT
# Cancellation may leave a detached container alive. Only export its compiler
# cache after compilation has stopped, never while the compiler may write it.
# The host still validates the export size if cleanup reported a warning.
if [ -n "${BASE_BUILD_DIR:-}" ] && [ -n "${CI_DEPENDS_CACHE_RUN:-}" ]; then
  if ! { printf '%s\n' "${CI_DEPENDS_CACHE_RUN}" > "${BASE_BUILD_DIR}/.ci-build-complete.tmp" &&
         mv -f -- "${BASE_BUILD_DIR}/.ci-build-complete.tmp" "${BASE_BUILD_DIR}/.ci-build-complete"; }; then
    echo "Warning: cannot record completed build; skipping canceled compiler-cache export" >&2
  fi
fi
ccache --version | head -n 1 && ccache --show-stats --verbose
ccache --print-stats | python3 "${BASE_ROOT_DIR}/ci/test/ccache_stats.py"
du -sh "${DEPENDS_DIR}"/*/
if [ -n "${CI_LIMIT_STACK_SIZE}" ]; then
  ulimit -s 512
fi

if [[ ${BARE_METAL_RISCV} == "true" ]]; then
    export BASE_BUILD_DIR
    "${BASE_ROOT_DIR}/ci/test/link-riscv.sh"
fi

if [ -n "$USE_VALGRIND" ]; then
  "${BASE_ROOT_DIR}/ci/test/wrap-valgrind.py"
fi

if [ "$RUN_CHECK_DEPS" = "true" ]; then
  "${BASE_ROOT_DIR}/contrib/devtools/check-deps.sh" "${BASE_BUILD_DIR}"
fi

if [[ "$CI_OS_NAME" == "macos" && "${GOAL}" = "install deploy" ]]; then
  unzip "${BASE_BUILD_DIR}/connectcoin-macos-app.zip" -d "${BASE_BUILD_DIR}/deploy"
  if ! ( codesign --verify "${BASE_BUILD_DIR}/deploy/ConnectCoin-Qt.app" ); then
    echo "Codesigning failed."
    false
  fi
fi

if [ "$RUN_UNIT_TESTS" = "true" ]; then
  LD_LIBRARY_PATH="${DEPENDS_DIR}/${HOST}/lib" \
  CTEST_OUTPUT_ON_FAILURE=ON \
  ctest --test-dir "${BASE_BUILD_DIR}" \
    --stop-on-failure \
    "${MAKEJOBS}" \
    --timeout $(( TEST_RUNNER_TIMEOUT_FACTOR * 60 ))
fi

if [ "$RUN_FUNCTIONAL_TESTS" = "true" ]; then
  # parses TEST_RUNNER_EXTRA as an array which allows for multiple arguments such as TEST_RUNNER_EXTRA='--exclude "rpc_bind.py --ipv6"'
  eval "TEST_RUNNER_EXTRA=($TEST_RUNNER_EXTRA)"
  LD_LIBRARY_PATH="${DEPENDS_DIR}/${HOST}/lib" \
  "${BASE_BUILD_DIR}/test/functional/test_runner.py" \
    "${MAKEJOBS}" \
    --tmpdirprefix "${BASE_SCRATCH_DIR}/test_runner/" \
    --ansi \
    --combinedlogslen=99999999 \
    --timeout-factor="${TEST_RUNNER_TIMEOUT_FACTOR}" \
    "${TEST_RUNNER_EXTRA[@]}" \
    --quiet \
    --failfast
fi

if [ "${RUN_TIDY}" = "true" ]; then
  cmake -B /tidy-build -DLLVM_DIR=/usr/lib/llvm-"${TIDY_LLVM_V}"/cmake -DCMAKE_BUILD_TYPE=Release -S "${BASE_ROOT_DIR}"/contrib/devtools/connectcoin-tidy
  cmake --build /tidy-build "$MAKEJOBS"
  cmake --build /tidy-build --target connectcoin-tidy-tests "$MAKEJOBS"

  set -eo pipefail
  # Filter out:
  # * qt qrc and moc generated files
  # * vendored RandomX sources, which follow the upstream project's style
  # * vendored Mbed TLS sources, which follow the upstream project's style
  jq 'map(select(.file | test("src/(qt/.*_autogen/.*\\.cpp$|randomx/)|_deps/connectcoin_mbedtls-src/") | not))' "${BASE_BUILD_DIR}/compile_commands.json" > tmp.json
  mv tmp.json "${BASE_BUILD_DIR}/compile_commands.json"

  cd "${BASE_BUILD_DIR}/src/"
  # Flush the Python driver's progress even when stdout is piped to tee.
  if ! ( PYTHONUNBUFFERED=1 run-clang-tidy-"${TIDY_LLVM_V}" -config-file="${BASE_ROOT_DIR}/src/.clang-tidy" -quiet -load="/tidy-build/libconnectcoin-tidy.so" "${MAKEJOBS}" | tee tmp.tidy-out.txt ); then
    grep -C5 "error: " tmp.tidy-out.txt
    echo "^^^ ⚠️ Failure generated from clang-tidy"
    false
  fi
fi

if [[ "${RUN_IWYU}" == true ]]; then
  # TODO: Consider enforcing IWYU across the entire codebase.
  FILES_WITH_ENFORCED_IWYU='/src/((bench|common|consensus|crypto|index|kernel|primitives|script|univalue/(lib|test)|util|zmq)/.*|node/(blockstorage|interfaces|miner|mining_args|utxo_snapshot)|rpc/mining|clientversion|core_io|signet|init)\.cpp'
  # Vendored dependencies follow their upstream projects' include style. Keep
  # IWYU focused on ConnectCoin sources, as the clang-tidy job does above.
  jq 'map(select(.file | test("src/randomx/|_deps/connectcoin_mbedtls-src/") | not))' "${BASE_BUILD_DIR}/compile_commands.json" > "${BASE_BUILD_DIR}/compile_commands_iwyu.json"
  jq --arg patterns "$FILES_WITH_ENFORCED_IWYU" 'map(select(.file | test($patterns)))' "${BASE_BUILD_DIR}/compile_commands_iwyu.json" > "${BASE_BUILD_DIR}/compile_commands_iwyu_errors.json"
  jq --arg patterns "$FILES_WITH_ENFORCED_IWYU" 'map(select(.file | test($patterns) | not))' "${BASE_BUILD_DIR}/compile_commands_iwyu.json" > "${BASE_BUILD_DIR}/compile_commands_iwyu_warnings.json"

  cd "${BASE_ROOT_DIR}"

  run_iwyu() {
    mv "${BASE_BUILD_DIR}/$1" "${BASE_BUILD_DIR}/compile_commands.json"
    {
      python3 -u "/include-what-you-use/iwyu_tool.py" \
             -p "${BASE_BUILD_DIR}" "${MAKEJOBS}" \
             -- -Xiwyu --cxx17ns -Xiwyu --mapping_file="${BASE_ROOT_DIR}/contrib/devtools/iwyu/connectcoin.core.imp" \
             -Xiwyu --max_line_length=160 \
             -Xiwyu --check_also='*/common/types\.h' \
             -Xiwyu --check_also='*/consensus/*\.h' \
             -Xiwyu --check_also='*/primitives/transaction_identifier\.h' \
             2>&1 || true
    } | tee /tmp/iwyu_ci.out
    python3 "/include-what-you-use/fix_includes.py" --nosafe_headers < /tmp/iwyu_ci.out
    git diff -U1 | ./contrib/devtools/clang-format-diff.py -binary="clang-format-${IWYU_LLVM_V}" -p1 -i -v
  }

  run_iwyu "compile_commands_iwyu_errors.json"
  if ! ( git --no-pager diff --exit-code ); then
    echo "^^^ ⚠️ Failure generated from IWYU"
    false
  fi

  run_iwyu "compile_commands_iwyu_warnings.json"
  git --no-pager diff
fi

if [ "$RUN_FUZZ_TESTS" = "true" ]; then
  # shellcheck disable=SC2086
  LD_LIBRARY_PATH="${DEPENDS_DIR}/${HOST}/lib" \
  "${BASE_BUILD_DIR}/test/fuzz/test_runner.py" \
    ${FUZZ_TESTS_CONFIG} \
    "${MAKEJOBS}" \
    -l DEBUG \
    "${DIR_FUZZ_IN}" \
    --empty_min_time=60
fi
