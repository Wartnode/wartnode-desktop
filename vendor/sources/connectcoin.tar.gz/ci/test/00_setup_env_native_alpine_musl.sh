#!/usr/bin/env bash
#
# Copyright (c) 2020-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

export TEST_RANDOMX_MOCK_POW=1  # Keep the musl job within its memory limit; randomx_tests still checks one real vector.

export CONTAINER_NAME=ci_native_alpine_musl
export CI_IMAGE_NAME_TAG="mirror.gcr.io/alpine:3.24"
export CI_BASE_PACKAGES="build-base musl-dev pkgconf curl ccache make ninja git python3-dev py3-pip which patch xz procps rsync util-linux bison e2fsprogs cmake dash linux-headers"
export PIP_PACKAGES="--break-system-packages pyzmq pycapnp"
export DEP_OPTS="DEBUG=1"
export GOAL="install"
export CONNECTCOIN_CONFIG="\
 --preset=dev-mode \
 -DREDUCE_EXPORTS=ON \
 -DCMAKE_BUILD_TYPE=Debug \
"
export TEST_RUNNER_EXTRA="--v2transport --usecli --extended --exclude feature_dbcrash"  # Run extended tests under --usecli and --v2transport, but exclude the very slow dbcrash
export CONNECTCOIN_CMD="connectcoin -m" # Used in functional tests
