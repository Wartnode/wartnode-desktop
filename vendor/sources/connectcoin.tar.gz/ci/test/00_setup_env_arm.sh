#!/usr/bin/env bash
#
# Copyright (c) 2019-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

export HOST=arm-linux-gnueabihf
export DPKG_ADD_ARCH="armhf"
export PACKAGES="python3-pip python3-zmq g++-arm-linux-gnueabihf libc6:armhf libstdc++6:armhf libfontconfig1:armhf libxcb1:armhf"
export PIP_PACKAGES="--break-system-packages pycapnp"
export CONTAINER_NAME=ci_arm_linux
export CI_IMAGE_NAME_TAG="mirror.gcr.io/debian:trixie"  # Check that https://packages.debian.org/trixie/g++-arm-linux-gnueabihf (version 14.x, similar to guix) can cross-compile
export CI_IMAGE_PLATFORM="linux/arm64"
export GOAL="install"
export CI_LIMIT_STACK_SIZE=1
export TEST_RANDOMX_MOCK_POW=1  # Avoid thousands of RandomX LIGHT hashes under ARM emulation.
# Fuzz and benchmark targets are covered by dedicated native jobs; compiling
# their hundreds of sources here needlessly dominates the 32-bit job.
# -Wno-psabi is to disable ABI warnings: "note: parameter passing for argument of type ... changed in GCC 7.1"
# This could be removed once the ABI change warning does not show up by default
export CONNECTCOIN_CONFIG=" \
  --preset=dev-mode \
  -DBUILD_BENCH=OFF \
  -DBUILD_FUZZ_BINARY=OFF \
  -DREDUCE_EXPORTS=ON \
  -DCMAKE_CXX_FLAGS='-Wno-psabi -Wno-error=maybe-uninitialized' \
"
