#!/usr/bin/env bash
#
# Copyright (c) 2019-present The Bitcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

export LC_ALL=C.UTF-8

export CONTAINER_NAME="ci_mac_native"  # macos does not use a container, but the env var is needed for logging
export PIP_PACKAGES="--break-system-packages pycapnp pyzmq"
export GOAL="install deploy"
export CMAKE_GENERATOR="Ninja"
export CI_OS_NAME="macos"
export TEST_RANDOMX_MOCK_POW=1  # Generic tests exercise chain logic; randomx_tests covers the real PoW implementation.
export NO_DEPENDS=1
export OSX_SDK=""
export CONNECTCOIN_CONFIG="\
  --preset=dev-mode \
  -DWITH_USDT=OFF \
  -DREDUCE_EXPORTS=ON \
  -DENABLE_RANDOMX_FAST_TEST=ON \
  -DCMAKE_EXE_LINKER_FLAGS='-Wl,-stack_size -Wl,0x80000' \
"
export CONNECTCOIN_CMD="connectcoin -m" # Used in functional tests
