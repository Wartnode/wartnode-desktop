# Depends build

This is a system of building and caching dependencies necessary for building
ConnectCoin Core. It supports cross-compilation. For more details see [description.md](description.md),
as well as [packages.md](packages.md) for how to add packages.

## Usage

Unless stated otherwise, run the dependency-build commands below from the
`depends` directory. From the repository root, enter it with:

    cd depends

Use `gmake` instead of `make` on the platforms whose instructions specify it.
The later CMake, `make -C depends`, and Nix-shell examples explicitly run from
the repository root.

### Ubuntu & Debian

    apt install cmake curl g++ make patch

Skip the following packages if you don't intend to use the GUI and will build with [`NO_QT=1`](#dependency-options):

    apt install bison ninja-build pkgconf python3 xz-utils

To build dependencies for the current arch+OS:

    make

### macOS

Install Xcode Command Line Tools and Homebrew Package Manager,
see [build-osx.md](../doc/build-osx.md).

    brew install cmake make ninja

To build dependencies for the current arch+OS:

    gmake

### FreeBSD

    pkg install bash cmake curl gmake

Skip the following packages if you don't intend to use the GUI and will build with [`NO_QT=1`](#dependency-options):

    pkg install bison ninja pkgconf python3

To build dependencies for the current arch+OS:

    gmake

### NetBSD

    pkgin install bash cmake curl gmake perl

To build dependencies for the current arch+OS:

    gmake

### OpenBSD

    pkg_add bash cmake curl gmake gtar

Skip the following packages if you don't intend to use the GUI and will build with [`NO_QT=1`](#dependency-options):

    pkg_add bison ninja

To build dependencies for the current arch+OS:

    gmake

### Alpine

    apk add bash build-base cmake curl make patch

Skip the following packages if you don't intend to use the GUI and will build with [`NO_QT=1`](#dependency-options):

    apk add bison linux-headers samurai pkgconf python3

To build dependencies for the current arch+OS:

    make

## Configuring ConnectCoin Core

**When configuring ConnectCoin Core, CMake by default will ignore the depends output.** In
order for it to pick up libraries, tools, and settings from the depends build,
you must specify the toolchain file.
In the above example for Ubuntu, a file named `depends/x86_64-pc-linux-gnu/toolchain.cmake` will be
created. To use it while configuring ConnectCoin Core, return to the repository
root (`cd ..` if still in `depends`). Use a build directory that has not already
been configured with a different toolchain; the example assumes `build` is new:

    cmake -B build --toolchain depends/x86_64-pc-linux-gnu/toolchain.cmake

## Dependency Options

The following can be set when running make: `make FOO=bar`

- `SOURCES_PATH`: Downloaded sources will be placed here
- `BASE_CACHE`: Built packages will be placed here
- `SDK_PATH`: Path where SDKs can be found (used by macOS)
- `FALLBACK_DOWNLOAD_PATH`: If a source file can't be fetched, try here before giving up
- `C_STANDARD`: Set the C standard version used. Defaults to `c11`.
- `CXX_STANDARD`: Set the C++ standard version used. Defaults to `c++20`.
- `NO_BOOST`: Don't download/build/cache Boost
- `NO_QT`: Don't download/build/cache Qt and its dependencies
- `NO_QR`: Don't download/build/cache packages needed for enabling qrencode
- `NO_ZMQ`: Don't download/build/cache packages needed for enabling ZeroMQ
- `NO_WALLET`: Don't download/build/cache libs needed to enable the wallet (SQLite)
- `NO_USDT`: Don't download/build/cache packages needed for enabling USDT tracepoints
- `NO_IPC`: Don't build Cap’n Proto and libmultiprocess packages. Default on Windows.
- `DEBUG`: Disable some optimizations and enable more runtime checking
- `HOST_ID_SALT`: Optional salt to use when generating host package ids
- `BUILD_ID_SALT`: Optional salt to use when generating build package ids
- `LOG`: Use file-based logging for individual packages. During a package build its log file
  resides in the `depends` directory, and the log file is printed out automatically in case
  of build error. After successful build log files are moved along with package archives
- `LTO`: Enable options needed for LTO. Does not add `-flto` related options to *FLAGS.

If some packages are not built, for example `make NO_WALLET=1`, the appropriate CMake cache
variables will be set when generating the ConnectCoin Core build system. In this case, `-DENABLE_WALLET=OFF`.

## Compiler Configuration

`CC` and `CXX` control target compilers. `build_CC` and `build_CXX` control
compilers for native build tools (e.g. `native_capnp`, `native_qt`), which
default to `gcc`/`g++` on Linux and `clang`/`clang++` on macOS/FreeBSD/OpenBSD
(see `./depends/builders/*.mk`).

On a system where the default build compiler is not available (e.g. Linux
without gcc/g++), you could use the following from the repository root to build
all packages using clang:

    make -C depends build_CC=clang build_CXX=clang++ CC=clang CXX=clang++

## Cross compilation

From the `depends` directory, to build for another arch+OS:

    make HOST=host-platform-triplet

For example:

    make HOST=x86_64-w64-mingw32 -j4

Common `host-platform-triplet`s for cross compilation are:

- `i686-linux-gnu` for Linux x86 32-bit
- `x86_64-linux-gnu` for Linux x86 64-bit
- `x86_64-w64-mingw32` for Windows using MSVCRT
- `x86_64-w64-mingw32ucrt` for Windows using UCRT
- `x86_64-apple-darwin` for Intel macOS
- `arm64-apple-darwin` for ARM macOS
- `arm-linux-gnueabihf` for Linux ARM 32-bit
- `aarch64-linux-gnu` for Linux ARM 64-bit
- `powerpc64-linux-gnu` for Linux POWER 64-bit (big endian)
- `powerpc64le-linux-gnu` for Linux POWER 64-bit (little endian)
- `riscv32-linux-gnu` for Linux RISC-V 32-bit
- `riscv64-linux-gnu` for Linux RISC-V 64-bit
- `s390x-linux-gnu` for Linux S390X

The paths are automatically configured and no other options are needed.

#### For macOS cross compilation

    apt install clang lld llvm zip

Clang 18 or later is required. You must also obtain the macOS SDK before
proceeding with a cross-compile. Under the depends directory, create a
subdirectory named `SDKs`. Then, place the extracted SDK under this new directory.
For more information, see [SDK Extraction](../contrib/macdeploy/README.md#sdk-extraction).

#### For Windows cross compilation

Using MSVCRT:

    apt install g++-mingw-w64-x86-64-posix

Using UCRT:

    apt install g++-mingw-w64-ucrt64

Some Ubuntu or Debian versions may not offer a working package. In this case,
you may install `nix-bin` and use the Nix shell from the repository root:

    apt install nix-bin
    NIX_BUILD_SHELL=bash HOST=x86_64-w64-mingw32 nix-shell contrib/devtools/shell-win64-cross.nix  # MSVCRT
    NIX_BUILD_SHELL=bash HOST=x86_64-w64-mingw32ucrt nix-shell contrib/devtools/shell-win64-cross.nix  # UCRT

#### For Linux cross compilation

Please note that package availability might depend on the arch+OS you are building on.

For Linux x86 32-bit cross compilation:

    sudo apt-get install g++-i686-linux-gnu binutils-i686-linux-gnu

For Linux x86 64-bit cross compilation:

    sudo apt-get install g++-x86-64-linux-gnu binutils-x86-64-linux-gnu

For Linux ARM 32-bit cross compilation:

    sudo apt-get install g++-arm-linux-gnueabihf binutils-arm-linux-gnueabihf

For Linux ARM 64-bit cross compilation:

    sudo apt-get install g++-aarch64-linux-gnu binutils-aarch64-linux-gnu

For Linux POWER 64-bit cross compilation (there are no packages for 32-bit):

    sudo apt-get install g++-powerpc64-linux-gnu binutils-powerpc64-linux-gnu g++-powerpc64le-linux-gnu binutils-powerpc64le-linux-gnu

For Linux RISC-V 64-bit cross compilation (there are no packages for 32-bit):

    sudo apt-get install g++-riscv64-linux-gnu binutils-riscv64-linux-gnu

For Linux S390X cross compilation:

    sudo apt-get install g++-s390x-linux-gnu binutils-s390x-linux-gnu

### Additional targets

    download: run 'make download' to fetch all sources without building them
    download-osx: run 'make download-osx' to fetch all sources needed for macOS builds
    download-win: run 'make download-win' to fetch all sources needed for win builds
    download-linux: run 'make download-linux' to fetch all sources needed for linux builds
