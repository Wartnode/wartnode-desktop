# Dependencies

These are the dependencies used by ConnectCoin Core.
You can find installation instructions in the `/doc/build-*.md` file for your platform, or self-compile
them using [depends](/depends/README.md).

## Compiler

ConnectCoin Core requires one of the following compilers.

| Toolchain | Minimum required |
| --- | --- |
| [Clang](https://clang.llvm.org) | [17.0](https://github.com/bitcoin/bitcoin/pull/33555) |
| [GCC](https://gcc.gnu.org) | [12.1](https://github.com/bitcoin/bitcoin/pull/33842) |
| [Xcode CLT](/doc/build-osx.md) | [16.2](https://github.com/bitcoin/bitcoin/pull/33932) |
| [MSVC](/doc/build-windows-msvc.md) | [18.3](https://github.com/bitcoin/bitcoin/pull/33861) |

## Required

### Build

| Dependency | Releases | Minimum required |
| --- | --- | --- |
| [Boost](../depends/packages/boost.mk) | [link](https://www.boost.org/users/download/) | [1.74.0](https://github.com/bitcoin/bitcoin/pull/34107) |
| CMake | [link](https://cmake.org/) | [3.22](https://github.com/bitcoin/bitcoin/pull/30454) |
| Mbed TLS | [link](https://github.com/Mbed-TLS/mbedtls/releases) | 3.6.7 (downloaded and hash-pinned by CMake) |

### Runtime

| Dependency | Releases | Minimum required |
| --- | --- | --- |
| glibc (GNU/Linux Guix binaries) | [link](https://www.gnu.org/software/libc/) | [2.31](https://github.com/bitcoin/bitcoin/pull/29987)

## Optional

### Build

| Dependency | Releases | Minimum required |
| --- | --- | --- |
| [Cap'n Proto](../depends/packages/native_capnp.mk) ([IPC](multiprocess.md)) | [link](https://capnproto.org/) | [0.7.1](https://github.com/bitcoin/bitcoin/pull/33241) |
| [libmultiprocess](../depends/packages/native_libmultiprocess.mk) ([IPC](multiprocess.md)) | [link](https://github.com/bitcoin-core/libmultiprocess/tags) | [v7.0-pre1](https://github.com/bitcoin/bitcoin/pull/33517) |
| Python (scripts, tests) | [link](https://www.python.org) | [3.10](https://github.com/bitcoin/bitcoin/pull/30527) |
| [Qt](../depends/packages/qt.mk) (gui) | [link](https://download.qt.io/archive/qt/) | [6.2](https://github.com/bitcoin/bitcoin/pull/30997) |
| [qrencode](../depends/packages/qrencode.mk) (gui) | [link](https://fukuchi.org/works/qrencode/) | N/A |
| [SQLite](../depends/packages/sqlite.mk) (wallet) | [link](https://sqlite.org) | [3.7.17](https://github.com/bitcoin/bitcoin/pull/19077) |
| [systemtap](../depends/packages/systemtap.mk) ([tracing](tracing.md)) | [link](https://sourceware.org/systemtap/) | N/A |
| [ZeroMQ](../depends/packages/zeromq.mk) (notifications) | [link](https://github.com/zeromq/libzmq/releases) | 4.0.0 |

The bundled libmultiprocess [CMake compatibility checks](../src/ipc/libmultiprocess/CMakeLists.txt)
add restrictions beyond the Cap'n Proto minimum: versions 0.7.0, 0.8.0, 0.9.0,
0.9.1, 0.10.0, 0.10.1, and 0.10.2 are rejected. Cap'n Proto 0.9.x and 0.10.x
are also rejected when building with Clang 16 or newer in C++20 mode.

### Runtime

The GUI runtime requirements below describe the GNU/Linux Guix binaries.
Builds with system-provided Qt or different configurations may have additional
runtime dependencies; see [the Linux runtime notes](INSTALL_linux.md).

| Dependency | Releases | Minimum required |
| --- | --- | --- |
| [Fontconfig](../depends/packages/fontconfig.mk) (gui) | [link](https://www.freedesktop.org/wiki/Software/fontconfig/) | 2.6 |
| [FreeType](../depends/packages/freetype.mk) (gui) | [link](https://freetype.org) | 2.3.0 |
