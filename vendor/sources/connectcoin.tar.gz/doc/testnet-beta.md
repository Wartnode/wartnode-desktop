# Testnet4 beta and mainnet separation

ConnectCoin mainnet has its own [launch genesis](mainnet-genesis.md), separate
from every development and test chain. The daemon, GUI and command-line tools
now default to mainnet. Existing testnet balances, wallets and chain data are
not converted to mainnet. Use a fresh, explicitly selected data directory for
mainnet if the base directory contains old development-chain data; do not use
`-reindex` as a cross-chain migration.

Use `-testnet4` for the public-test-network profile or `-regtest` for local
tests. The name `testnet4` is an inherited internal identifier, not the fourth
public ConnectCoin beta. All four test-chain genesis blocks and message starts
were reset for P2C mask v1 on September 9, 2026, as described below.

To continue using the beta, select `-testnet4` or `-chain=testnet4` explicitly.
An explicit network selection in the command line or configuration still takes
precedence. No configuration file is generated or rewritten by the default
change. Testnet4 wallets and chain data continue to use the `testnet4/`
subdirectory. The Kernel API also defaults to mainnet.

Testnet4 uses P2P port 48179 and RPC port 48178. RPC should remain private; expose
only the P2P service to testers. Testnet4's only built-in DNS/DDNS bootstrap
hostname is `connectcoin1.com`. Mainnet has separate bootstrap hostnames on
its native P2P port 48173, listed in the
[operator policy](dnsseed-policy.md#current-bootstrap-hostnames). No public
seed is added to testnet3, signet or regtest. Fixed seed IP addresses remain
empty on all networks. A public beta additionally needs reachable peers,
operational DNS, ongoing RandomX mining, and distribution of test coins. Merely
listing hostnames in the client does not deploy those services. No test
balances are promised mainnet conversion.

## Testnet4 bootstrap DNS

The only built-in base hostname is `connectcoin1.com`. Its bootstrap node must
run testnet4 explicitly (`-testnet4` or `-chain=testnet4`) and listen on TCP
48179. Mainnet's `connectcoin2.com`, `connectcoin3.com`, `connectcoin4.com` and
`dememzea.tplinkdns.com` are not testnet4 seeds. Reassigning a hostname in
source does not change the network running on the corresponding node.

On a fresh start with no known peers, the client queries the seeds automatically.
`-dnsseed=0` disables DNS seeding; `-connect` also disables it by default. Existing
peer discovery, proxy handling and connection limits are unchanged. A seed only
provides peer addresses: blocks and transactions still undergo normal validation.

The current discovery code requests A/AAAA records for `x9.<seed>`, for example
`x9.connectcoin1.com`,
where `9` selects `NODE_NETWORK | NODE_WITNESS`. These records must point only to
reachable, non-pruned ConnectCoin testnet4 nodes on TCP port 48179. The client
also assumes BIP324 support for these filtered results, so advertised nodes must
support v2 transport. Do not return website/CDN addresses or peers from another
network. Publish AAAA only when incoming IPv6 connections actually work.

For a static bootstrap deployment, DNS can be hosted by the domain's DNS
provider: point both the base hostname and its `x9.` subdomain to the corresponding
seed node's public IP, with a TTL of at least 60 seconds. Serve these as DNS-only records,
not through an HTTP reverse proxy. No wildcard record is needed; unsupported
service filters should not claim capabilities the node lacks.

If the filtered name has no addresses, or the client uses a name proxy, Core
falls back to connecting to `<seed>:48179` to request peer addresses.
Thus the base hostname must also resolve to a reachable testnet4 P2P node, not
just a DNS server. This fallback is an address-fetch connection, not a promise
of a permanent connection to that node.

Running the authoritative DNS service on the VPS itself is optional and is
separate from running `connectcoind`. Provider-hosted DNS does not require
opening port 53 on the node. A dedicated crawler/DNS seeder can replace the
static records later, returning checked testnet4 peers. See the
[operator policy](dnsseed-policy.md); one bootstrap operator is an initial
central dependency, not a substitute for independent seeds.

An optional [CPU miner](cpu-mining.md) is available from the wallet's Mining
tab or the `startmining` RPC. It supports mainnet, testnet4 and regtest, is disabled at
each startup, and does not require a loaded wallet when given a reward address.

## P2C mask v1 genesis reset (September 9, 2026)

The testnet4 beta genesis allocates `10,000,000 CONN` to the same wallet-owned
type-1 public key generated on September 7. No new private key is needed:

- Public key: `2ef316afd6177619f68ecfc6521fc3fcbf7faa2b25273f6ddea7971fae0de144`
- Address: `tcc1p9me3dt7kzampna5welr9y87rljlhl23ty5nn7mw757t3ltsdu9zqu5cd3u`
- Genesis: `710dc5910cbef40216bd82ccfb66af2273b2b1d336b034c5794966904cb603bf`
- Coinbase transaction / Merkle root: `e09a12d2aca740a06be984897fa268d4f03317c2363748d4ab69768ed92ca555`
- Header time: `1788912001`; nonce: `913`; difficulty bits: `0x1f00ffff`.
- Message start: `77 d6 6c bc`; P2P port remains `48179`.

The header was mined with real RandomX v2. The private key is held in a local
wallet, not this repository. The original key's ownership was verified during
the September 7 setup; this reset reuses its public key without accessing or
regenerating the private key.
The allocation remains subject to the 100-block coinbase maturity rule.

The other reset genesis parameters (all with the same 10,000,000 CONN allocation
and their previous public keys) are:

| Chain | Header time | Nonce | Bits | Genesis hash |
| --- | ---: | ---: | --- | --- |
| Testnet3 | 1788912000 | 66621 | `1f00ffff` | `1025889d725c5d64c3ee38ab07d2de279ab57036a2482186c65806d6c0291787` |
| Signet | 1788912002 | 2069 | `1f00ffff` | `a694dccdc04a316a4f4fe496f311aff981392f25ea18e4b7f77d9f449b9089fc` |
| Regtest | 1296688602 | 20 | `207fffff` | `53c5145452f6957a2674ab904726afc2d7643c4a4fb9c2beab193ea983e500f0` |

Each coinbase message is `ConnectCoin <network> | P2C mask v1 | 2026-09-09`, where
`<network>` is `testnet3`, `testnet4`, `signet`, or `regtest`. Regtest deliberately
keeps its historical header clock so tests using historical mock times remain
valid; its coinbase, Merkle root, nonce and chain identity are new. The genesis
blocks use real RandomX, not test-only mock proof of work. The isolated historic
mainnet test fixture is unchanged and is not an operational network.

This is a new chain, not a migration of old test balances. “P2C mask v1” names
the network/output-layout reset introducing the required one-byte signature
mask; the TLS proof remains version 2 with work tag `ConnectCoin/P2C/work/v2`.
Version-1 P2C proofs are not accepted. See [pay-to-connect.md](pay-to-connect.md).

Wallet database identifiers are separate from P2P message starts and retain
their pre-reset values. Backups from the same test-network profile remain
recognizable without editing their SQLite headers. Other network profiles are
still rejected; signet wallets also remain specific to their configured
challenge. This compatibility preserves keys and wallet metadata, not the old
chain or its funds. Temporary wallet files created by unreleased reset development
builds that used the new P2P magic as their database identifier are not accepted.
The wallet's saved chain locator is a separate safeguard: a different genesis
is still rejected by default, even when its database identifier matches. Only
an intentional reset restore should override that safeguard as described below.

### Wallets containing pre-mask P2C transactions

The stable database identifier preserves recognition of the wallet, not old
transaction serialization. A wallet containing P2C transactions written before
the one-byte mask was introduced can fail to load with `Wallet corrupted` and
`Invalid PAY_TO_CONNECT signature algorithms mask` or `end of data` in its log.
That error can be caused by incompatible transaction history; it does not by
itself mean that the private keys are damaged. Do not delete or recreate the
wallet. `-walletcrosschain=1` and a rescan cannot parse those old records.

For an intentional test-network reset, an **offline, explicitly destructive**
recovery command is available. Keep the original wallet backup untouched and
work on a separate copy placed in the new data directory's wallet directory.
Stop every process using that copy before running, for example:

```sh
connectcoin-wallet -testnet4 -datadir=/absolute/new-data -wallet=recovery-copy \
  -backupdir=/absolute/new-backup-directory \
  -confirm=DELETE-TRANSACTION-HISTORY reset-tx-history
```

The command requires an explicit data directory and wallet name, checks the
actual SQLite network identity, and is unavailable for mainnet. The backup
directory must be absolute and must not exist. It creates `wallet.dat` there,
checks database integrity and all backed-up records, then atomically removes
**all** transaction records, witness variants, and persistent coin locks. This
also removes unconfirmed transactions and transaction-specific comments and
payment-request history; a rescan cannot recover such metadata. Keys (including
encrypted keys), descriptors and their caches, address labels, flags, and all
other records remain byte-for-byte unchanged. The saved block locator is
preserved, so the separate cross-chain safeguard is not bypassed by this tool.

After successful reset, load the recovery copy using the one-time
`-walletcrosschain=1` override and explicit `-testnet4`, unlock it if encrypted, and run
`rescanblockchain 0`. Then stop normally and restart without the override.
Only funds on the new chain can be recovered; old-chain balances are not
migrated. This is not a general repair for damaged keys or a way to make
obsolete transactions valid. On failure the backup directory is retained for
inspection; an incomplete or unverified backup must not replace the original.
Before deleting history, the tool flushes the verified backup file and, on
POSIX systems, checks synchronization of both its directory and the parent
directory. On Windows, directory synchronization is unavailable through this
tool: flushing the file does not guarantee persistence of the new directory
across sudden power loss. Even successful sync requests depend on filesystem
and hardware behavior. Always retain the separate original wallet backup and
perform this procedure on a recovery copy, not the only copy of a wallet.

Before upgrading an existing node:

1. Stop it normally and back up its wallets outside Git, including an offline
   copy of the fund wallet. Never delete a wallet to reset a chain.
2. Preserve the entire old data directory. Start the new binary using an
   explicit `-testnet4` and a separate, newly created `-datadir=<new-directory>`; do not reuse
   an old block index, chainstate, mempool, settings or peer database.
3. For this intentional reset only, start the new binary with
   `-testnet4 -datadir=<new-directory> -walletcrosschain=1`, restore the desired wallet
   backup and explicitly run `rescanblockchain 0` in that wallet's RPC console
   (unlock an encrypted wallet first). This scan includes the new genesis;
   do not assume that restoration at height zero scanned its allocation.
   The override permits the old genesis
   in the wallet's saved locator; it does not bypass wallet network/challenge
   identifiers or block validation. Do not edit the backup's database header.
   Keys remain usable, but old chain transactions and balances do not become
   new-chain funds. The testnet4 genesis key controls the new allocation.
   Stop the node normally after restoration/rescan, then restart in the new
   directory without `-walletcrosschain`. Do not save that override permanently
   in the configuration. Keep the original backup untouched.
   If incompatible pre-mask P2C history prevents loading, use the offline-copy
   procedure above before attempting the load/rescan again.
4. Upgrade all VPS/seed nodes and peers to the same build and fresh chain before
   advertising them. The September 9 reset preserved the DNS names and port
   48179; the current seed assignments are listed above. Updating source code
   does not deploy anything to those machines.

Normal startup refuses a loaded block index with the wrong genesis. Reindexing
is not a supported migration of the old chain. The reset performs no automatic
data deletion or wallet conversion. This testnet key must not be reused for the
mainnet allocation.

## Wallet fees on a new network

When fee estimation has insufficient transaction history and `fallbackfee` is
unset or zero, automatic wallet sends use the next block's economic minimum:
the subsidy weight cost per kvB plus 1,000 connects/kvB. This follows halvings
and reorgs, rather than keeping the initial subsidy's fee forever. Higher
mempool, relay or wallet minimums still apply; the maximum-fee safeguards are
unchanged. A nonzero `fallbackfee` still selects a fixed alternative when
estimation is unavailable, subject to the same minimums.

This applies to GUI sends, funding/send RPCs and manual P2C claim preparation.
No confirmation deadline is implied by the minimum rate. Explicit transaction
fee rates retain their existing behavior. Fee estimation RPCs still report
insufficient data when there is no estimate: the economic minimum is a wallet
policy, not a fabricated estimate.

## Historical test fixtures

`src/test/util/chainparams.cpp` supplies the retired development genesis only to
the `test_util` library. It is a historical test vector, not a launch commitment,
and is not linked into the daemon, GUI, or Kernel library. There is no runtime
switch or configuration option to install it. Tests of storage, subsidy,
retargeting, genesis spending and fuzzing retain mainnet rules with this fixture.
Production-factory tests separately verify the launch genesis and its two
allocations, mainnet startup and explicit testnet selection. The original 35 mainnet address RPC
vectors run in C++ against the fixture, including rejection of legacy output
types. HTTP RPC coverage runs on regtest and is restored to the default suite.

The retired development chain and all beta chains remain separate from the
production mainnet genesis; no runtime option installs the historical fixture.
