# ConnectCoin public identity

This file inventories ConnectCoin identifiers and their review requirements.
Values may still change during development. Registry and name-conflict checks
below were last refreshed on 2026-08-25.

Enabling the mainnet genesis and default network in the software does not resolve
the identity, registry or release-process reviews recorded below.

## Pre-launch blockers

The current brand is suitable for local development, but is **not cleared for a
public launch**:

- “Connect Coin” has already been used by the XCON cryptocurrency/token.
- A separate 2025 GitHub repository describes a Connects Health USA
  `Connectcoin` project and `CONN` token.
- A United States application for the `CONNECT COIN` mark covered
  cryptocurrency exchange, payment, storage, and key-generation services. The
  application is reported as abandoned, but that does not establish that the
  name is free to use in every jurisdiction.
- `ConnectCoin` has also been used as the name of a Motorola-branded Bluetooth
  accessory and application.
- `COIN CONNECT` is a registered US mark owned by DraftKings for online casino
  and games-of-chance services. Its scope is different, but it is another close
  mark that a professional search must evaluate.
- The earlier development ticker `CC` is already assigned to Canton Coin in
  SLIP-0044 and is actively used as that network's exchange ticker. Adopting
  `CONN` does not establish an exclusive claim to the new ticker.
- `connectcoin.com` was already registered and resolving when checked. GitHub
  accounts using `Connectcoin` and `Connectcoinnode` also already existed.
- The project uses `connectcoincrypto/connectcoin` on GitHub
  and the DNS/DDNS hostnames listed in
  [testnet-beta.md](testnet-beta.md#testnet4-bootstrap-dns) for testnet4 bootstrap.
  These assignments do not by themselves establish a release-signing identity,
  security contact or package-publishing account. Verify `git remote -v` before
  any push.

Development application identifiers use the reserved domain
`connectcoin.invalid` and the reverse prefix `invalid.connectcoin`. Replace them
only after the project controls a stable domain; do not use `connectcoin.org`,
which is already registered and is not identified as project-owned.

Before any public mainnet, exchange listing, fundraising, or distribution,
perform a professional trademark and naming search in the intended countries,
check domains and software-package namespaces, and either clear or replace the
name and ticker. The exact package name returned no package in npm, PyPI,
crates.io, or NuGet during this snapshot, but absence is neither a reservation
nor legal clearance. A web and registry search is evidence of conflicts, not a
substitute for legal review.

## User-facing identity

| Item | ConnectCoin value |
| --- | --- |
| Product | ConnectCoin Core |
| Executable prefix | `connectcoin` / `connectcoind` |
| Data directory | `ConnectCoin` on Windows/macOS, `.connectcoin` on Unix |
| Configuration | `connectcoin.conf` |
| Payment URI | `connectcoin:` |
| Display unit | `CONN` |
| Atomic unit | `connect` (`con`) |
| Signed-message header | `ConnectCoin Signed Message:\n` |
| P2P user agent | `/ConnectCoin:<version>/` |

`CONN` is ConnectCoin's development ticker, not a claim of global uniqueness.
The separate Connects Health USA project listed above has also used `CONN`.
ConnectCoin previously used `CC`; the SLIP-0044 registry uses that symbol for
Canton Coin at coin type 6767, and Canton's own whitepaper identifies `CC` as its
abbreviation. This ConnectCoin display change does not change Canton's ticker.
ConnectCoin has no registered BIP44/SLIP-0044 coin type yet. The ticker still
requires clearance and a coin type must be registered before public wallet
interoperability is advertised. The atomic-unit labels `connect` and `con` are
project-specific display names and have no standards registration.

## Address and key encodings

Only the Bech32m HRPs are accepted for current transaction outputs. The
Base58 P2PKH/P2SH codecs and version bytes remain inherited compatibility
parsers; they do not identify consensus-valid type-1 outputs.

| Network | P2PKH | P2SH | WIF | HD public | HD private | Segwit HRP |
| --- | ---: | ---: | ---: | --- | --- | --- |
| Mainnet | 28 (`C…`) | 87 (`c…`) | 80 (`C…` compressed) | `ccpub…` (`a7c73fd9`) | `ccprv…` (`a7c73b9f`) | `cc` |
| Testnet3/testnet4/signet | 65 (`T…`) | 127 (`t…`) | 178 (`T…` compressed) | `tcub…` (`04313a97`) | `tcpr…` (`04313316`) | `tcc` |
| Regtest | 65 (`T…`) | 127 (`t…`) | 178 (`T…` compressed) | `tcub…` (`04313a97`) | `tcpr…` (`04313316`) | `ccrt` |

The `cc` human-readable prefix does not currently appear in the official
SLIP-0173 registry. It is therefore provisional, not reserved. Submit a
SLIP-0173 registration before a public launch and re-check the registry at that
time.

The four HD version-byte values above do not appear in SLIP-0132. Their readable
prefixes were selected for this development fork, but they are not registered
or globally collision-free. Register them, or replace them with accepted values,
before claiming hardware-wallet or multi-wallet interoperability. Base58 P2PKH,
P2SH, and WIF version bytes also need an ecosystem-wide collision review; there
is no single authoritative registry that makes a choice safe merely because it
produces the desired first character.

The `connectcoin:` payment URI is implemented by the GUI but does not appear in
the IANA URI Schemes registry. It is a project-local scheme until registered;
external applications must not assume global ownership of it.

## Network separation

The development monetary policy caps individual monetary values at
`100,000,000 CONN`. On mainnet, testnet3, testnet4, and signet, the recurring
block subsidy begins at `15 CONN` and halves every 3,000,000 blocks. Public-network
blocks target a 10-second interval. The existing public test networks have a
separate spendable genesis output of `10,000,000 CONN`. The mainnet launch genesis
contains two type-1 outputs of `5,000,000 CONN` each, assigned to the two distinct
MuSig aggregate public keys committed in its coinbase. Each output requires one
valid BIP340 signature under its aggregate key and obeys coinbase maturity.
The retired development genesis remains a separate test-only fixture.
With the launch allocation and every available subsidy
claimed by empty blocks, integer rounding produces a maximum planned issuance of
`99,999,984.9955000000 CONN`. One CONN is subdivided into `10,000,000,000`
connects, so wallet and RPC amounts use up to ten decimal places. Regtest keeps
its 150-block halving interval.

The consensus block-weight limit is `50,000,000`. An empty block may claim the
entire scheduled subsidy. Non-coinbase transaction weight linearly reduces the
claimable subsidy to 90% at the full limit, with the withheld amount rounded
down to whole connects. The native block
assembler therefore includes a transaction package only when its modified fees
exceed the marginal subsidy penalty. The theoretical serialized-data ceiling is
50 MB per 10-second block (5 MB/s); non-witness data consumes four weight units
per byte and reaches a lower byte throughput.

Encrypted v2 transport uses ConnectCoin's four-byte extension of the BIP324
packet-length descriptor. This is necessary for 50 MB messages and makes the
wire format intentionally incompatible with stock Bitcoin BIP324 peers.

The largest atomic amount is `10^18` connects, which is greater than the largest
integer (`2^53 - 1`) represented exactly by an IEEE-754 binary64 value such as a
JavaScript `Number`. RPC integrations must parse returned amount tokens with an
arbitrary-precision decimal type and should submit amounts as decimal strings;
converting monetary values through binary floating point can lose connects.

The public test networks use valid x-only P2PK development-fund keys whose
private keys are deliberately absent from the source tree. Testnet4 has a
separate fund key since its September 7, 2026 genesis reset. Regtest alone uses a
deterministic key with published private material so automated tests can spend
its genesis allocation. Fund-key custody and backups are separate from publishing
public keys in chain parameters. Changing a genesis output changes the chain
identity. Mainnet uses its independently defined launch genesis and aggregate
keys; test-network allocations and the retired development fixture do not
become mainnet funds. See [testnet-beta.md](testnet-beta.md).

| Network | RPC port | P2P port | Onion bind | Message start | Genesis hash |
| --- | ---: | ---: | ---: | --- | --- |
| Mainnet (default) | 48172 | 48173 | 48174 | `d9 51 a5 e2` | `30a3a7543f593b6343873a16aeb61005dce0fe3f4169ab34039316b2a9bb373e` |
| Testnet3 | 48175 | 48176 | 48177 | `c7 29 1f f5` | `1025889d725c5d64c3ee38ab07d2de279ab57036a2482186c65806d6c0291787` |
| Testnet4 | 48178 | 48179 | 48180 | `77 d6 6c bc` | `710dc5910cbef40216bd82ccfb66af2273b2b1d336b034c5794966904cb603bf` |
| Signet | 48181 | 48182 | 48183 | `30 4c 2f 0c` (default `OP_TRUE` challenge) | `a694dccdc04a316a4f4fe496f311aff981392f25ea18e4b7f77d9f449b9089fc` |
| Regtest | 48184 | 48185 | 48186 | `3a f8 3b e3` | `53c5145452f6957a2674ab904726afc2d7643c4a4fb9c2beab193ea983e500f0` |

These four test-chain genesis blocks and message starts were reset for P2C mask v1
on September 9, 2026. Public keys, ports and address encodings are unchanged.
Signet message start is the first four bytes of SHA256d over the serialized
string `ConnectCoin signet P2C mask v1 network` followed by the serialized challenge
vector. See [testnet-beta.md](testnet-beta.md) before upgrading an existing node.

Mainnet starts from its own launch genesis. Preserve any historical development
data and wallets and use a fresh `-datadir` for that chain; `-reindex` is not a
genesis migration. The shared testnet address encodings do not permit reusing
testnet wallets or balances as mainnet allocations.

Fixed seed arrays are empty on every network, and the generated seed header
is not included by the chain parameters. Testnet4 includes only
`connectcoin1.com` as a DNS/DDNS bootstrap hostname. Mainnet includes
`connectcoin2.com`, `connectcoin3.com`, `connectcoin4.com` and
`dememzea.tplinkdns.com`. Bootstrap nodes must run the matching network on its
native P2P port (48173 for mainnet, 48179 for testnet4); source configuration
does not deploy or reconfigure nodes, DNS records or services. See the
[operator policy](dnsseed-policy.md#current-bootstrap-hostnames) and
[testnet-beta.md](testnet-beta.md#testnet4-bootstrap-dns) for operational
requirements. No public DNS seed is configured for testnet3, signet or regtest.
Regtest retains only the non-resolving `dummySeed.invalid.` test-framework
placeholder; it is not a bootstrap server.

All fifteen chosen RPC/P2P/onion-bind ports are in IANA's User Port range
(1024–49151). No entry from 48172 through 48186 appeared in the registry checked on the date
above. “No entry” means unassigned at that moment, not reserved for ConnectCoin.
Re-check all ports and request assignments before public
deployment. Test networks may also share one registered service name with
distinct documented ports if that is the final deployment design.

## Deliberately inherited internal identifiers

Source filenames, C++ types, translation contexts, BIP test vectors, copyright
notices, upstream links, and protocol domain separators such
as `Bitcoin seed` or `bitcoin_v2_shared_secret` may keep their upstream
spelling. Renaming those does not improve user-visible identity and can break
standards compatibility, attribution, build tooling, or reviewable history.
Installed executables, CMake targets, test-framework environment variables,
application metadata, RPC descriptions, network constants, addresses, paths,
CI outputs, developer tools, and ConnectCoin package artifacts must not use
inherited product names.

Project-owned include guards and the unique-name helper macro use the
`CONNECTCOIN_` prefix. Third-party subtree identifiers remain unchanged.

The experimental kernel API is a ConnectCoin-native, intentionally
ABI-incompatible fork. Its library, header, pkg-config file, CMake targets,
export macros, and C symbol prefix are named `libconnectcoinkernel`,
`connectcoinkernel.h`, `CONNECTCOINKERNEL_*`, and `cck_*`. Do not reintroduce
the inherited public `libbitcoinkernel`, `BITCOINKERNEL_*`, or `btck_*` names.

Translation catalogs retain their inherited filenames and Qt context names.
ConnectCoin maintains their user-visible product terminology and translations
through its [translation workflow](translation_process.md). The
[coverage report](translation-coverage.md) distinguishes translated messages
from runtime English fallbacks; AI-assisted updates are not native-speaker
approval. Historical references, attribution, and protocol identifiers must not
be changed as a side effect of translating product text.

The inherited previous-release downloader and compatibility fixtures remain
inactive reference material. Bitcoin Core release binaries are not valid
ConnectCoin compatibility targets because the networks have different genesis
blocks and identity constants. CI must not run those tests until ConnectCoin has
project-owned release artifacts and checksums.

## Registries

- [SLIP-0173 address-prefix registry](https://github.com/satoshilabs/slips/blob/master/slip-0173.md)
- [SLIP-0044 coin-type registry](https://github.com/satoshilabs/slips/blob/master/slip-0044.md)
- [SLIP-0132 HD version-byte registry](https://github.com/satoshilabs/slips/blob/master/slip-0132.md)
- [IANA URI Schemes registry](https://www.iana.org/assignments/uri-schemes/)
- [IANA Service Name and Port Number registry](https://www.iana.org/assignments/service-names-port-numbers/)
- [Prior `CONNECT COIN` US trademark application](https://trademarks.justia.com/888/02/connect-88802798.html)
- [Prior XCON asset listing](https://www.coinbase.com/price/connect-coin)
- [Connect Social filing describing its Connect Coin](https://www.sec.gov/Archives/edgar/data/1967788/000196778823000002/Connect_Social_Form_C.pdf)
- [Motorola/Binatone ConnectCoin product listing](https://binatoneglobal.com/end-of-life-products/)
- [Registered `COIN CONNECT` US mark](https://furm.com/trademarks/coin-connect-97293368)
- [Official Canton documentation identifying Canton Coin as `CC`](https://docs.canton.network/overview/understand/canton-coin)
- [Existing Connects Health USA `Connectcoin` repository](https://github.com/Connectshealthusa/connectcoin)
- [`connectcoin.com` RDAP record](https://rdap.verisign.com/com/v1/domain/CONNECTCOIN.COM)
